//Davi
#ifndef HISTORICO_H
#define HISTORICO_H

void registrarOperacao(int idUsuario, const char* operacao);
void mostrarHistorico(int idUsuario);

#endif
