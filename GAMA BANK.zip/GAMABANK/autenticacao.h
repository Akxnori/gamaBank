//alysson 
#ifndef AUTENTICACAO_H
#define AUTENTICACAO_H

int autenticar(const char* usuario, const char* senha);

#endif
