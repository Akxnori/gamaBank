//Thiago
#ifndef CONSULTA_SALDO_H
#define CONSULTA_SALDO_H

void exibirSaldo(int idUsuario);

#endif
