//Alexandre
#ifndef SAQUE_H
#define SAQUE_H

int sacar(int idUsuario, float valor);

#endif
