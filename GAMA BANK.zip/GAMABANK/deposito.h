//Henrique
#ifndef DEPOSITO_H
#define DEPOSITO_H

void depositar(int idUsuario, float valor);

#endif
